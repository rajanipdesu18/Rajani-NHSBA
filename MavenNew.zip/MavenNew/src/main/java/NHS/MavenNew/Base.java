package NHS.MavenNew;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Base {

	public static WebDriver driver;
	public static Properties prop;
	public WebDriver initializeDriver() throws IOException{
		// TODO Auto-generated method stub
		 prop= new Properties();
			FileInputStream fis=new FileInputStream("//home//rajani//eclipse-workspace//MavenNew//src//main//java//NHS//MavenNew//data.properties");

			prop.load(fis);
			String browserName=prop.getProperty("browser");
			System.out.println(browserName);

			if(browserName.equals("chrome"))
			{
				 System.setProperty("webdrive.chrome.driver", "//home//rajani//chromedriver_linux64//chromedriver.exe");
				driver= new ChromeDriver();
					//execute in chrome driver
				
			}
			else if (browserName.equals("firefox"))
			{
				 driver= new FirefoxDriver();
				//firefox code
			}
			
			
			return driver;




	}

}
