package StepDefinition;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import NHS.MavenNew.Base;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class steps  extends Base{
@Test
@Given("^I am person from Wales$")
public void i_am_person_from_wales() throws IOException, InterruptedException{
    // Write code here that turns the phrase above into concrete actions
	
	driver=initializeDriver();	
			
	driver.get("https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/start");	
	driver.findElement(By.xpath("//button[@tabindex='2']")).click();
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	driver.findElement(By.xpath("//label[@id='label-wales']")).click();
	driver.findElement(By.cssSelector("input[type='submit']")).click();
	Thread.sleep(2000l);
		
}
	
@Test

@When("^I put my circumstances into the checkers tool$")
public void i_put_my_circumstances_into_the_checkers_tool() throws IOException, InterruptedException{
    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.id("dob-day")).sendKeys("25");
	driver.findElement(By.id("dob-month")).sendKeys("05");
	driver.findElement(By.id("dob-year")).sendKeys("1967");
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-yes")).click();
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-no")).click();
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-no")).click();
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-no")).click();
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	driver.findElement(By.id("label-yes")).click();
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-no")).click();
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-no")).click();
	driver.findElement(By.className("button")).click();
	driver.findElement(By.id("label-no")).click();
	driver.findElement(By.className("button")).click();
	/*driver.findElement(By.id("radio-no")).click();
	driver.findElement(By.className("button")).click();*/
	Thread.sleep(2000L);
	
	
}
@Test
@Then("^I should get a result of whether I will get help or not$")
public void i_should_get_a_result_of_whether_i_will_get_help_or_not() throws IOException{
    // Write code here that turns the phrase above into concrete actions
	System.out.println("I should get a result of whether I will get help or not");
	driver.get("https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/result");

}

}
